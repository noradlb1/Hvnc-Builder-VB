﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks

Namespace HVNC.Resources
	Friend Class Source
	End Class
End Namespace
